<?php

//require_once "libs/rb.php";
// R::setup( 'mysql:host=localhost;dbname=gb', 'root', 'root');




$servername = "localhost";
$username = "root";
$password = "root"; // Пароль, если используется MAMP PRO. Если обычный MAMP, оставьте пустым.
$dbname = "gb";

$db =  @mysqli_connect($servername, $username, $password, $dbname) or die('нет соединения');

mysqli_set_charset($db, "utf8") or die("ошибка кодировки");
