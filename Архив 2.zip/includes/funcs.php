<?php
function save_mess() {
    global $db;
    $name = mysqli_real_escape_string($db, $_SESSION['logged_user'] -> login);
    $text = mysqli_real_escape_string($db, $_POST['text']);
    $query = "INSERT INTO gb (name, text) VALUES ('$name', '$text')";

    mysqli_query($db, $query);

        // // Создаем новую запись в таблице gb
        // $message = R::dispense('gb');

        // // Заполняем поля name и text
        // $message->name = $_SESSION['logged_user']->login;
        // $message->text = $_POST['text'];
    
        // // Сохраняем запись в базе данных
        // R::store($message);
    
}

function get_mess() {
    global $db;
    $query = "SELECT * FROM gb ORDER BY id DESC";

    $res = mysqli_query($db, $query);
    return mysqli_fetch_all($res, MYSQLI_ASSOC);
}

// function get_mess() {
//     // Получаем все записи из таблицы gb, отсортированные по id в порядке убывания
//     return R::findAll('gb', ' ORDER BY id DESC ');
// }

function print_arr($arr) {
    echo '<pre>' . print_r($arr, true) . '</pre>';
}

