<?php 

    require_once "includes/db.php";
    require_once 'includes/funcs.php';
    require_once 'includes/connect.php';


    $data = $_POST;
    if (isset($_SESSION['logged_user'])) {
    $this_user = R::findOne('users', 'id = ?', array($_SESSION['logged_user']->id));
    }
    // echo $this_user;

    function loadAvatar($avatar){
        $type = $avatar['type'];
        $name = md5(microtime()) . '.' . substr($type, strlen("image/"));
        $dir = "uploads/avatars/";

        $uploadfile = $dir . $name;
        
        if(move_uploaded_file($avatar['tmp_name'], $uploadfile)) {
            $this_user = R::findOne('users', 'id = ?', array($_SESSION['logged_user']->id));
            $this_user -> avatar = $name;
            R::store($this_user);
        } else {
            return false;
        }
        return true;
    }

    if(!empty($_POST)) {

        $avatar = $_FILES['avatar'];

        if (avatarSecurity($avatar)) loadAvatar($avatar);
        else echo "Вы можете использовать типы png, jpg, jpeg, gif и webp";
        // $type = $avatar['type'];  
        // echo "Тип файла: $type<br>";
        header("Location: settings.php");
        exit;
        
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <!-- <link rel="stylesheet" href="style/style.css"> -->
    <link rel="stylesheet" href="style/main.css"> 
    <link rel="stylesheet" href="style/settings.css">
    <link rel="stylesheet" href="style/news.css"> 


    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Comfortaa:wght@300..700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,350;1,400;1,500;1,700;1,900&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+Display:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
</head>

        <body style="background-color: rgba(0, 89, 255, 0.102);">
        <div class="main-box-left">
            <div class="my_acc">
            <?php $this_user = R::findOne('users', 'id = ?', array($_SESSION['logged_user']->id));?>
                <img src="uploads/avatars/<?php echo $this_user -> avatar?>" alt="">
                <span> <?php echo $_SESSION['logged_user']->login ?></span> 
                <button class="to-exit"><img src="images/info.png" alt=""></button></a> 

                
            </div>
       
               
            <div class="main-box-left-open">
                <a href="settings.php"><img src="images/settings.png" alt="">
                <span>Настройки</span></a>
                <a href="logout.php"><img src="images/exit.png" alt="">
                <span>Выйти</span></a>
            </div>        <a href="index.php"><img src="images/main.png" alt=""><span> Главная</span></a> <br>
        <a href="users.php"><img src="images/peoples.png" alt=""><span>Пользователи</span></a> <br>
        <a href="mychats.php"><img src="images/chat.png" alt=""><span>Чаты</span></a>
        <br>
        
                <br><br>

    <!-- <a href="logout.php"><img src="images/exit.png" alt=""><span>Выйти</span></a> -->
    </div>
    <div class="main-box-right">
        <!-- <a href="users.php">пользователи</a> -->
        <br>
        
    <!-- <a href="logout.php">Выйти</a> -->
    </div>
    
            
        </div>
        <div class="main-box" style="height: 95vh;">

<br>
    <h1 class="hello">Настройте свой профиль</h1>
    <h1 class="main-hr"></h1>
    <br>

    <div class="remake-avatar">

    
    <?php $this_user = R::findOne('users', 'id = ?', array($_SESSION['logged_user']->id));?>

                <img src="uploads/avatars/<?php echo $this_user -> avatar?>" alt="" class="settigs-photo">

        <form action="settings.php" method="POST" enctype="multipart/form-data">
        <input type="hidden" name="form_type" value="avatar">
                <input type="file" name="avatar">
                <br>
                
                <button type="submit" name="set_avatar" style="margin-top: 10px">Обновить фото</button>
                </form>
                </div>
        </div>
</div>
            </body>
<script type="text/javascript" src="js/main.js"></script>

    
</html>