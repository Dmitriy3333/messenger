// var textarea_chat = document.querySelector(".text-area-chat");
// // var lines_bilo = textarea_news.value.split('\n').length; // количество изначально 
// var div_chat_area = document.querySelector(".form-main"); // это div, где находится textarea
// var height_div_chat = div_chat_area.clientHeight;

// function countLines() {
    
//         // var lines = textarea_chat.value.split('\n').length; // количество переносов текста
//         var height_izmen = 28 * lines;
//         div_chat_area.style.height = height_izmen + "px";
//         textarea_chat.style.height = height_div_chat - 38 + height_izmen + "px";
//     // }
//     // document.querySelector(".all-messages").innerHTML = height_izmen;
// }

// textarea_chat.oninput = function() {
//     countLines();
//     // alert(1234);
// }

var buttonExit = document.querySelector(".to-exit");
var exitWindow = document.querySelector(".main-box-left-open");

buttonExit.onclick = function() {
    if (exitWindow.style.display == "block") {
        exitWindow.style.display = "none";
    } else {
        exitWindow.style.display = "block";
    }
}

// это для новостей
var textarea_news = document.querySelector(".text-area-news");
// var lines_bilo = textarea_news.value.split('\n').length; // количество изначально 
var div_text_area = document.querySelector(".form-main"); // это div, где находится textarea
var height_div = div_text_area.clientHeight;

function countLines() {
    
    // while(height_div < (400 + "px")) {
        var lines = textarea_news.value.split('\n').length; // количество переносов текста
        var height_izmen = 28 * lines;
        textarea_news.style.height = height_izmen + "px";
        div_text_area.style.height = height_div - 38 + height_izmen + "px";
    // }
    // document.querySelector(".all-messages").innerHTML = height_izmen;
}

textarea_news.oninput = function() {
    countLines();

}


// это для чатов

