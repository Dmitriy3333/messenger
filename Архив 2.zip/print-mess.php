
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style/chat.css">
    <!-- <meta http-equiv="refresh" content="5"> -->
    <link rel="stylesheet" href="style/main.css">

</head>

<?php
require_once "includes/db.php";
require_once "libs/rb.php";

// session_start();

$path = $_SESSION['path'];
$messages2 = R::findAll($path, 'ORDER BY id ASC');

foreach ($messages2 as $message1): ?>
    <div class='message <?php echo $message1['name'] == $_SESSION['logged_user']->login ? "i-am" : ""; ?>'>
        <span><?php echo htmlspecialchars($message1['name']); ?></span>
        <div class="text-mess"><?php echo nl2br(htmlspecialchars($message1['text'])); ?></div>
        <span class="date-mess"><?php echo htmlspecialchars($message1['date']); ?></span>
    </div>
<?php endforeach; ?>