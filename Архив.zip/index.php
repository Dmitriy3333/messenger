<?php
    require_once "includes/db.php";
    require_once 'includes/funcs.php';
    require_once 'includes/connect.php';

    if(!empty($_POST)) {
        save_mess();
        header("Location: {$_SERVER['PHP_SELF']}");
        exit;
    }

    $messages = get_mess();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <!-- <link rel="stylesheet" href="style/style.css"> -->
    <link rel="stylesheet" href="style/main.css"> 
    <link rel="stylesheet" href="style/log.css">
    <link rel="stylesheet" href="style/news.css"> 


    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Comfortaa:wght@300..700&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,350;1,400;1,500;1,700;1,900&display=swap" rel="stylesheet">

</head>

    
    <?php if(isset($_SESSION['logged_user'])): ?>
        <body style="background-color: rgba(0, 89, 255, 0.102);">
        <div class="main-box-left">
            <div class="my_acc">
            <img src="images/men.png" alt=""><span> <?php echo $_SESSION['logged_user']->login ?></span> <button class="to-exit"><img src="images/info.png" alt=""></button></a> 
            
            </div>
            
            <div class="main-box-left-open"><a href="logout.php"><img src="images/exit.png" alt=""><span>Выйти</span></a></div>
        <a href="index.php" class="active"><img src="images/main.png" alt=""><span> Главная</span></a> <br>
        <a href="users.php"><img src="images/peoples.png" alt=""><span>Пользователи</span></a> <br>
        <a href="mychats.php"><img src="images/chat.png" alt=""><span>Чаты</span></a>
        <br>
        
    <!-- <a href="logout.php"><img src="images/exit.png" alt=""><span>Выйти</span></a> -->
    </div>
    <div class="main-box-right">
        <!-- <a href="users.php">пользователи</a> -->
        <br>
        
    <!-- <a href="logout.php">Выйти</a> -->
    </div>
    <div class="form-main">
            <form method="post" action="index.php" class="get-text">
            <span>Предложите свою новость</span>
                <p>
                    
                    <!-- <label for="name">Текст:</label> <br> -->
                    <textarea name="text" id="text"></textarea>
                    <button type="submit" >></button>
                </p>     
                
            </form>
            
        </div>
        <div class="main-box">
        <!-- Авторизован! <br>
        Привет, <?php //echo $_SESSION['logged_user'] -> login;?>
        <hr> -->
        
    <hr>
    <br>
    
        <div class="all-messages" id="textContainer">
        <?php if(!empty($messages)): ?>
            <?php foreach($messages as $message): ?>
        
                <div class="message">
                
                    
                    <div class="mess-inf">
                        <img src="images/men.png" alt="" class="ph">
                        <div class="mess-inf-text">
                        <span><?php echo $message['name']?></span> 
                        <span><?php echo $message['date']?> </span>
            </div>
                    </div>

                    <div class="text-mess"><?php echo nl2br($message['text'])?></div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
        </div>
        
        </div>

            </body>
<script type="text/javascript" src="js/main.js"></script>
    <?php else: ?>
        <body style="background-color:#fff;">
        <div class="box">
        <h1>Вход в систему</h1>
        <hr>
        <div class="form-main-log">
           
        <a href="login.php">Авторизация</a><br>
        <a href="signup.php">Регистрация</a>
        </div>
        <!-- <a href="users.php">пользователи</a> -->
    </div>
    </body>
    
    <?php endif; ?>

    
</html>