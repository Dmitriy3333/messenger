
var buttonExit = document.querySelector(".to-exit");
var exitWindow = document.querySelector(".main-box-left-open");

buttonExit.onclick = function() {
    if (exitWindow.style.display == "block") {
        exitWindow.style.display = "none";
    } else {
        exitWindow.style.display = "block";
    }
    
    //alert(123);
}