<?php
    require_once "includes/db.php";
    require_once "libs/rb.php";

    $path = $_SESSION['path']; // связь пользователей для названия бд
    $sobes = $_SESSION['sobes']; // собеседник 

    $is_this_person = 0;

    $person = R::load('users', $sobes); // собеседник

    $this_person_id = $_SESSION['logged_user']['id'];
    $this_person_id_well = R::load('users', $this_person_id); // сам пользователь 
    
    $person_id = $person -> id; // id собеседника
    $person_id_well = R::load('users', $person_id);
    // echo $this_person_id;
    // echo $person -> id;

    try {
        R::count($path);
        $is_this_person = 1;
    } catch (Exception $e) {
        // Создаём таблицу, если она не существует
        
        $label = R::dispense($path);
        R::store($label);


    }
        if(!empty($_POST)) {
            // echo $is_this_person;
            $name = htmlspecialchars($_SESSION['logged_user']->login);
            $text = htmlspecialchars($_POST['text']);
            $message1 = R::dispense($path);
            $message1->name = $name;
            $message1->text = $text;

            $date = date('Y-m-d H:i');
            $message1->date = $date;

            // это должно выполняться только 1 раз - при первой переписке
            $bilo = $this_person_id_well -> people; // для текущего пользователя
            $bilo_sobes = $person_id_well -> people; // для собеседника пользователя
            if (!str_contains($bilo, "f" . $sobes)) {
                $this_person_id_well -> people = $bilo. "f". (string)$sobes;
                R::store($this_person_id_well);
            }
            if (!str_contains($bilo_sobes, "f" . $this_person_id)) {
                $person_id_well -> people = $bilo_sobes. "f". (string)$this_person_id;
                R::store($person_id_well);
            }
            

            R::store($message1);
            header("Location: {$_SERVER['PHP_SELF']}");
            exit;
        }

        $messages2 = R::findAll($path, 'ORDER BY id ASC');
?>



            


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style/chat.css">

    <link rel="stylesheet" href="style/main.css">

</head>

<body style="background-color: rgba(0, 89, 255, 0.102);">
<div class="main-box-left">
            <div class="my_acc">
            <img src="images/men.png" alt=""><span> <?php echo $_SESSION['logged_user']->login ?></span> <button class="to-exit"><img src="images/info.png" alt=""></button></a> 
            
            </div>
            
            <div class="main-box-left-open"><a href="logout.php"><img src="images/exit.png" alt=""><span>Выйти</span></a></div>
        <a href="index.php"><img src="images/main.png" alt=""><span> Главная</span></a> <br>
        <a href="users.php"><img src="images/peoples.png" alt=""><span>Пользователи</span></a> <br>
        <a href="mychats.php"  class="active"><img src="images/chat.png" alt=""><span>Чаты</span></a>
        <br>
        
    <!-- <a href="logout.php"><img src="images/exit.png" alt=""><span>Выйти</span></a> -->
    </div>

    <div class="main-box">
    
    <hr>
    <br>
    <div class="info">Собеседник: <?php echo $person -> login;?></div>
    <div class="all-messages" id="textContainer">

        
        <?php if(!empty($messages2)): ?>
            <?php foreach($messages2 as $message1): ?>
        
                <?php if ($message1['name'] == $this_person_id_well -> login) {
                    echo "<div class='message i-am'>";
                    } else {
                        echo "<div class='message'>";
                        };?>
                <span >
                        <?php echo $message1['name']?></span> <span> </span>
                    <div class="text-mess"><?php echo nl2br($message1['text'])?></div>
                    <!-- <hr> -->
                    <span class="date-mess"><?php echo $message1['date']?></span>
                    
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
            </div>

            <div class="form-main">
        <form method="post" action="chat.php" class="get-text">

        <p>
            <label for="name"></label> 
            <!-- <text type="text" name="name"> -->
            <textarea name="text" id="text"></textarea><button type="submit" >></button>
        </p>     
            
        
    </form>
            </div>
            </div>
            </body>
            <script>
        document.addEventListener("DOMContentLoaded", function() {
            var textContainer = document.getElementById("textContainer");
            textContainer.scrollTop = textContainer.scrollHeight;
        });
    </script>
    <script type="text/javascript" src="js/main.js"></script>

</html>