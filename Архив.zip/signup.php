<?php
    require_once "includes/db.php";

    $data = $_POST;
    if (isset($data['do_signup']))
    {
        // регистрация
        $errors = array();
        if (trim($data['login']) == '')
        {
            $errors[] = '<span class="error">Введите логин</span>';
        }
        if (trim($data['email']) == '')
        {
            $errors[] = '<span class="error">Введите email</span>';
        }

        if (trim($data['password']) == '')
        {
            $errors[] = '<span class="error">Введите пароль</span>';
        }

        if (($data['password_2']) != $data['password'])
        {
            $errors[] = '<span class="error">Повторный пароль неверен</span>';
        }

        if (R::count('users', "login = ?", array($data['login'])) > 0)
        {
            $errors[] = '<span class="error">Логин занят</span>';
        }

        if (empty($errors)) 
        {
            // регестрируем
            $user = R::dispense('users'); // создание новой таблицы
            $user -> login = $data['login'];
            $user -> email = $data['email'];
            $user -> password = password_hash($data['password'], PASSWORD_DEFAULT);
            R::store($user);

            echo '<div style="color: green">Успешно!<a href="login.php">Авторизоваться</a></div><hr>';

        } else {
            echo '<div>'.array_shift($errors).'</div>';
        }
        
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <!-- <link rel="stylesheet" href="style/style.css"> -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Comfortaa:wght@300..700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="style/log.css">

</head>
<body>
<div class="box">
    <h1>Регистрация</h1>
    <hr>
    <form action="signup.php" method="POST">
    <div class="form-main-log" style="margin-top: -90px; width: 60%; margin-left: 20%;">
        <p style="margin-top:130px">
            <span>Ваш логин:</span>
            <input type="text" name="login" value="<?php echo @$data['login'];?>">
        </p>
        <p>
            <span>Ваш email:</span>
            <input type="email" name="email" value="<?php echo @$data['email'];?>">
        </p>
        <p>
            <span>Ваш пароль:</span>
            <input type="password" name="password" value="<?php echo @$data['password'];?>">
        </p>
        <p>
            <span>Повтор пароля:</span>
            <input type="password" name="password_2" value="<?php echo @$data['password_2'];?>">
        </p>

        <br>
        <button type="submit" name="do_signup" style="margin-top: 10px">Зарегестрироваться</button>
        </div>
    </form>
    <a href="index.php" class="back">< Назад</a>
    </div>
</body>
</html>