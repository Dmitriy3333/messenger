<?php
function save_mess() {
    global $db;
    $name = mysqli_real_escape_string($db, $_SESSION['logged_user'] -> login);
    $text = mysqli_real_escape_string($db, $_POST['text']);
    $query = "INSERT INTO gb (name, text) VALUES ('$name', '$text')";

    mysqli_query($db, $query);
}

function get_mess() {
    global $db;
    $query = "SELECT * FROM gb ORDER BY id DESC";

    $res = mysqli_query($db, $query);
    return mysqli_fetch_all($res, MYSQLI_ASSOC);
}

function print_arr($arr) {
    echo '<pre>' . print_r($arr, true) . '</pre>';
}

