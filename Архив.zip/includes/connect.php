<?php
$servername = "localhost";
$username = "root";
$password = "root"; // Пароль, если используется MAMP PRO. Если обычный MAMP, оставьте пустым.
$dbname = "gb";

$db =  @mysqli_connect($servername, $username, $password, $dbname) or die('нет соединения');
// var_dump($db);

mysqli_set_charset($db, "utf8") or die("ошибка кодировки");
// function print_arr($arr) {
//     echo '<pre>' . print_r($arr, true) . '</pre>';
// }