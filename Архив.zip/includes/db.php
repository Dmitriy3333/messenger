<?php
require_once "libs/rb.php";
R::setup( 'mysql:host=localhost;dbname=users',
        'root', 'root');

session_start();